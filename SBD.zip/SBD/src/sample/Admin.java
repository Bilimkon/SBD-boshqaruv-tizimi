package sample;

import com.mysql.jdbc.Connection;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.ListView;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import javafx.scene.control.Button;
import javafx.scene.control.DatePicker;

import java.io.IOException;
import java.math.BigDecimal;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.Statement;
import java.sql.*;
import java.util.List;

import javafx.scene.control.TextField;
import sample.Core.Maxsulot;
import sample.Core.demo;
import sample.DAO.DaoUtils;
import sample.DAO.MaxsulotDao;
import sample.Controller;
import sample.MaxsulotTableView.MaxsulotTable;

import javax.swing.*;


public class Admin {

    public TextField textAdminNomi;
    public Button btnAdminQoshish;

    public TextField textAdminItemNomi;
    public TextField textAdminItemBarcode;
    public TextField textAdminItemType;
    public TextField textAdminItemQuantity;
    public TextField textAdminItemCost;
    public TextField textAdminItemStatus;
    public DatePicker textAdminItemDate;
    public DatePicker textAdminItemExpireDate;
    public TextField textAdminItemTurlari;

    private MaxsulotDao maxsulotDao;
    private Admin admina;


    private java.sql.Connection myConn;

    public Admin(MaxsulotDao theMaxsulotDAO) throws Exception {
        this();
        maxsulotDao = theMaxsulotDAO;


    }

    public Admin() throws Exception {


        String url1 = "jdbc:mysql://localhost:3306/sbd";
        String name = "Humoyun";
        String password = "Bilimkon";

        // connect to database
        myConn = DriverManager.getConnection(url1, name, password);

        System.out.println("Employee DAO - DB connection successful to: " + url1);


    }


    public void menuAsosiyOynaAction() {

        Parent root;
        try {
            root = FXMLLoader.load(getClass().getResource("sample.fxml"));
            Stage stage = new Stage();
            stage.setTitle("SBD boshqaruv tizimi");
            stage.setScene(new Scene(root, 1080, 720));
            stage.show();
            // Hide this current window (if this is what you want)
            //( (this.textAdminNomi)).getScene().getWindow().hide();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void menuAdminSatistikaAction() {
        Parent root;
        try {
            root = FXMLLoader.load(getClass().getResource("Statistika.fxml"));
            Stage stage = new Stage();
            stage.setTitle("SBD boshqaruv tizimi");
            stage.setScene(new Scene(root, 1080, 720));
            stage.show();
            // Hide this current window (if this is what you want)
            ((Node) (this.textAdminItemBarcode)).getScene().getWindow().hide();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public BigDecimal convertStringToBigDecimal(String salaryStr) {

        BigDecimal result = null;

        try {
            double salaryDouble = Double.parseDouble(salaryStr);

            result = BigDecimal.valueOf(salaryDouble);
        } catch (Exception exc) {
            System.out.println("Invalid value. Defaulting to 0.0");
            result = BigDecimal.valueOf(0.0);
        }

        return result;
    }

    public void saveMaxsulot() throws Exception {//Save  maxsulot ajoyib maxsulotlarni databasega qoshadigan funksiya

        try {


            String item_name = textAdminItemNomi.getText();

            String item_Barcode = textAdminItemBarcode.getText();

            String item_type = textAdminItemType.getText();

            String item_Miqdiri = textAdminItemQuantity.getText();

            int itemInt_Miqdori = Integer.parseInt(item_Miqdiri);

            String item_cost = textAdminItemCost.getText();
            BigDecimal itemCost = convertStringToBigDecimal(item_cost);
            String item_status = textAdminItemStatus.getText();
            boolean apple = false;
            String item_date = textAdminItemDate.getValue().toString();
            String itemAdminExpireDate = textAdminItemExpireDate.getValue().toString();
            String item_turlari = textAdminItemTurlari.getText();



    /*  //  Maxsulot tempMahsulot =new Maxsulot(item_name,item_type,itemInt_Miqdori,itemCost,apple,item_date,itemAdminExpireDate,item_Barcode,item_turlari);
        demo  thedemo1= new demo("Anor",12,"2222222","Sohiba");
        System.out.print("ishladi\n");
        try{
            System.out.print("ishladi\n");
         //  maxsulotDao.AddMaxsulot(thedemo1);
          //  refreshMahsulotView();

            JOptionPane.showMessageDialog(null,"Maxsulot muvoffaqqiyatli saqlandi","Muvvoffaqqiyatli malga oshirildi",JOptionPane.INFORMATION_MESSAGE);
            System.out.print("ishladi yana");

        }catch (Exception exc){
            JOptionPane.showMessageDialog(null,"Mahsulotni saqlashda  xatolik:"+exc.getMessage(),"Xato!",JOptionPane.ERROR_MESSAGE);
               System.out.print("ishlamadi");

        }
        */
            PreparedStatement myStmt = null;
            BigDecimal apple12 = new BigDecimal(10);
            try {
                //Prepare Statement
                myStmt = myConn.prepareStatement("INSERT INTO maxsulotlar"
                        + "(item_name,item_type,item_quantity,item_cost,item_status,item_date,item_expire_date,item_barcode,item_turlari)"
                        + "VALUES (?,?,?,?,?,?,?,?,?)", Statement.RETURN_GENERATED_KEYS);



                /////////////////////////////////////////////////////////////////////


                myStmt.setString(1, item_name);
                myStmt.setString(2, item_type);
                myStmt.setInt(3, itemInt_Miqdori);
                myStmt.setBigDecimal(4, itemCost);

                myStmt.setBoolean(5, true);
                myStmt.setString(6, item_date);
                myStmt.setString(7, itemAdminExpireDate);
                myStmt.setString(8, item_Barcode);
                myStmt.setString(9, item_turlari);

                myStmt.executeUpdate();

                System.out.print("Bajarildi");
            } catch (Exception exc) {
                JOptionPane.showMessageDialog(null, "Hammasini to'ldiring ", "Xato", JOptionPane.ERROR_MESSAGE);
            }


        }catch (Exception exc){
            JOptionPane.showMessageDialog(null, "Hammasini to'ldiring ", "Xato", JOptionPane.ERROR_MESSAGE);
        }
    }





    public void btnAdminQoshishAction()throws  Exception{
      saveMaxsulot();

    }
    public void refreshMahsulotView(){
        try{
            List<Maxsulot> maxsulotList=maxsulotDao.getAllMaxsulot();

         // MaxsulotTable model = new MaxsulotTable(maxsulotList);
          // table.setModel(model);


        }catch (Exception exc){
            JOptionPane.showMessageDialog(null,"Xatolik! "+exc,"Xato",JOptionPane.ERROR_MESSAGE);

        }


    }



}
