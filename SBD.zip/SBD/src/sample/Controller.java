package sample;

import java.awt.*;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.MenuItem;
import javafx.scene.control.TextField;
import javafx.scene.control.TableView;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.CheckBox;
import javafx.scene.image.ImageView;
import javafx.scene.image.Image;
import javafx.stage.Stage;
import jdk.nashorn.internal.scripts.JO;
import sample.DAO.MaxsulotDao;
import sample.Core.*;
import sample.DAO.*;
import sample.Core.Maxsulot;

import java.io.IOException;
import java.math.BigDecimal;
import java.sql.DriverManager;
import java.util.*;
import sample.MaxsulotTableView.MaxsulotTable;

import java.awt.List;
import java.awt.Component;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.swing.*;



public class Controller {

    private Connection myConn;
    private MaxsulotDao maxsulotDao;
    public Button btnIzlash;
    public Button btnBarcodeOk;
    public TextField textIzlash;
    public TextField textBarcode;
    public TextField textItemNomi;
    public TextField textItemNarxi;
    public TextField textItemMiqdori;
    public TextField textItemUmumiyNarx;
    public TextField textItemTolanganSumma;
    public TextField textItemQarzQolganSumma;
    public TextField textItemPlastikMiqdori;
    public TextField textItemPlastikQolgani;
    public TextField textItemPlastikUmumiy;

    public Label textAreaBarcode;
    public Label textAreaBarcode1;
    public Label textAreaBarcode2;
    public Label textUmumiyNarx;
    public ListView textUmumiyNarxList;
    public ListView textItemList;
    public CheckBox checkNaqt;
    public CheckBox checkQarz;
    public  TableView maxsulotTable;
    public TableColumn itemName;
    public TableColumn itemType;
    public TableColumn itemCost;
    public TableColumn itemQuanity;
    public TableColumn itemBarcode;
    public  TableColumn itemDate;
    public  MenuItem menuAdmin;

    String itemNameIzlash;
    String itemBarcodeBarcode;
    String itemBarcodeType;
    String itemBarcodeName;
    BigDecimal itemBarcodeCost;
    int itemBarcodeQuantity;
    Date itemBarcodeDate;
    Date itemBarcodeExpireDate;
    boolean itemBarcodeStatus;
    String itemBarcodeTurlari;
    public  int  countBarCode=0 ;





    public Controller()throws Exception{//******************************** Constructor******************************


        String  url1 = "jdbc:mysql://localhost:3306/sbd";
        String  name = "Humoyun";
        String  password="Bilimkon";

        // connect to database
        myConn = DriverManager.getConnection(url1, name, password);

        System.out.println("Employee DAO - DB connection successful to: "+url1);

        try {
            maxsulotDao = new MaxsulotDao();

        } catch (Exception exc) {
            System.out.print("This is Warning  from the  JOptionPane");
            JOptionPane.showMessageDialog(null , "Error","Error",JOptionPane.ERROR_MESSAGE);
        }
    }
    public void btnIzlashAction() {// ********************** Button Izlash*******************

        JOptionPane.showMessageDialog(null, "Error", "Error", JOptionPane.ERROR_MESSAGE);
        itemNameIzlash= textIzlash.getText();
        try {
            java.util.List<Maxsulot> maxsulotlar = null;

            if (itemNameIzlash != null && itemNameIzlash.trim().length() > 0) {
                maxsulotlar = maxsulotDao.searchMaxsulot(itemNameIzlash);
            } else {
                maxsulotlar = maxsulotDao.getAllMaxsulot();
            }

            // create the model and update the "table"
            for (Maxsulot temp : maxsulotlar) {
                System.out.println(temp);
            }

        } catch (Exception exc) {

            // JOptionPane.showMessageDialog(null,"Error"+exc,"Error",JOptionPane.ERROR_MESSAGE);
        }

    }
    public  void btnBarcodeAction()throws Exception{//***************************btnOkAction******************************

        countBarCode++;

        itemBarcodeBarcode = textBarcode.getText();

        Statement statement = null;
        Controller controller=null;
        ArrayList<String> list = new ArrayList<String>();
         String  name = "apple";
         String  name2= "meva";
        ResultSet myRs= null;

      try {
           statement = myConn.createStatement();
           myRs = statement.executeQuery("select * FROM  maxsulotlar");

           while (myRs.next()) {
               itemBarcodeName = myRs.getString("item_name");
               itemBarcodeType = myRs.getString("item_type");
               itemBarcodeCost = myRs.getBigDecimal("item_cost");
               itemBarcodeQuantity = myRs.getInt("item_quantity");
               itemBarcodeDate = myRs.getDate("item_date");
               itemBarcodeExpireDate = myRs.getDate("item_expire_date");
               itemBarcodeStatus = myRs.getBoolean("item_status");
               itemBarcodeTurlari = myRs.getString("item_turlari");

               statement = myConn.createStatement();
               myRs = statement.executeQuery("select item_barcode FROM  maxsulotlar");

               while (myRs.next()) {

                   if (itemBarcodeBarcode.equals(myRs.getString("item_barcode"))) {

                       textAreaBarcode.setText("   Barcode: " + itemBarcodeBarcode + "\n   Nomi: " + itemBarcodeName + "\n   Turi: " + itemBarcodeType);
                       textAreaBarcode1.setText("   Narxi: " + itemBarcodeCost + "\n" + "   Miqdori: " + itemBarcodeQuantity + "\n   Xolati: " + itemBarcodeStatus);
                       textAreaBarcode2.setText("   Sana: " + itemBarcodeDate + "\n   Yaroqlilik sanasi: " + itemBarcodeExpireDate + "\n   Turlari: " + itemBarcodeTurlari);
                       textItemNomi.setText("" + itemBarcodeName);
                       textItemNarxi.setText("" + itemBarcodeCost);

                   } else {
                    //   JOptionPane.showMessageDialog(null,"Error","This barcode is doesn't exist", JOptionPane.ERROR_MESSAGE);
                   }
               }
           }
       }
        finally {
            DaoUtils.close(statement,myRs);
        }
    }

    public void UmumiyNarx(){

        String apple2 = textItemMiqdori.getText();
        if(textItemMiqdori.getText().equals("")){

            textUmumiyNarx.setText("    "+itemBarcodeCost);
            textItemPlastikUmumiy.setText(" "+itemBarcodeCost);
            textItemUmumiyNarx.setText(" "+itemBarcodeCost);

        }else{
            try {
                BigDecimal apple = new BigDecimal(apple2);
                BigDecimal butunSumma = apple.multiply(itemBarcodeCost);
                BigDecimal umumiyHisob = new BigDecimal(.00);
                //int  soni = apple.intValue();

                for (int a = 0; a < countBarCode; a++) {

                    umumiyHisob = umumiyHisob.add(butunSumma);

                    for (int b = 0; b < countBarCode; b++) {
                        umumiyHisob=umumiyHisob.add(butunSumma);

                    textUmumiyNarx.setText("    " + umumiyHisob);
                    textItemPlastikUmumiy.setText(" " + butunSumma);
                    textItemUmumiyNarx.setText(" " + butunSumma);
                }
            }


     }
            catch (Exception exe){

            }
        }
    }
    public void btnXisobAction(){

        UmumiyNarx();
        checkQarzBox();

        checkQarz.setSelected(false);
        textItemUmumiyNarx.setVisible(false);
        textItemTolanganSumma.setVisible(false);
        textItemQarzQolganSumma.setVisible(false);
}
    public void checkNaqtBox(){

        if(checkNaqt.isSelected()){
            textItemPlastikMiqdori.setVisible(true);
            textItemPlastikQolgani.setVisible(true);
            textItemPlastikUmumiy.setVisible(true);
            checkQarz.setDisable(true);
        }
        else{
            textItemPlastikMiqdori.setVisible(false);
            textItemPlastikQolgani.setVisible(false);
            textItemPlastikUmumiy.setVisible(false);
            checkQarz.setDisable(false);
        }
    }
    public  void checkQarzBox(){

             if(checkQarz.isSelected()) {
                 textItemUmumiyNarx.setVisible(true);
                 textItemTolanganSumma.setVisible(true);
                 textItemQarzQolganSumma.setVisible(true);
                 //JOptionPane.showMessageDialog(null,"Error","Error",JOptionPane.ERROR_MESSAGE);
             }else{
                 textItemUmumiyNarx.setVisible(false);
                 textItemTolanganSumma.setVisible(false);
                 textItemQarzQolganSumma.setVisible(false);

             }
    }
    public void menuAdminAction(){
        Parent root;
        try {
            root = FXMLLoader.load(getClass().getResource("Admin.fxml"));
            Stage stage = new Stage();
            stage.setTitle("SBD boshqaruv tizimi");
            stage.setScene(new Scene(root, 1080, 720));
            stage.show();
            // Hide this current window (if this is what you want)
            ((Node) (this.textItemQarzQolganSumma)).getScene().getWindow().hide();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    public void menuSampleAction(){

        Parent root;
        try {
            root = FXMLLoader.load(getClass().getResource("Login.fxml"));
            Stage stage = new Stage();
            stage.setTitle("SBD boshqaruv tizimi");
            stage.setScene(new Scene(root, 1080, 720));
            stage.show();
            // Hide this current window (if this is what you want)
            ((Node) (this.textItemPlastikQolgani)).getScene().getWindow().hide();
        } catch (IOException e) {
            e.printStackTrace();
        }

    }
    public  void btnSampleSotishAction(){
        countBarCode=0;
    }
}
