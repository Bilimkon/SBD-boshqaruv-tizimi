package sample.Core;

import java.math.BigDecimal;
import java.math.BigInteger;
import  java.util.Date;

public class History {

    private int userId;
    private int itemId;
    private String userFirstName;
    private String userLastName;
    private String itemName;
    private String itemType;
    private int itemQuantity;
    private BigInteger itemBarcode;
    private Date  paidDate;
    private BigDecimal totalCost;
    private BigDecimal paidCost;
    private BigDecimal remainingCost;
    private BigInteger remainingQuantity;


    public History(int userId, int itemId, String userFirstName,String userLastName, String itemName,String itemType, int itemQuantity ,BigInteger itemBarcode, Date paidDate,BigDecimal totalCost,BigDecimal paidCost,BigDecimal remainingCost,BigInteger remainingQuantity){
        super();
        this.userId = userId;
        this.itemId=itemId;
        this.userFirstName=userFirstName;
        this.userLastName=userLastName;
        this.itemName=itemName;
        this.itemType= itemType;
        this.itemQuantity= itemQuantity;
        this.itemBarcode= itemBarcode;
        this.paidCost=paidCost;
        this.paidDate=paidDate;
        this.totalCost=totalCost;
        this.remainingCost= remainingCost;
        this.remainingQuantity=remainingQuantity;
    }

    public int getUserId() {
        return userId;
    }
    public void setUserId(int userId){
        this.userId=userId;
    }

    public int getItemId() {
        return itemId;
    }
    public void setItemId(int itemId){
        this.itemId= itemId;
    }

    public String getUserFirstName() {
        return userFirstName;
    }
    public  void setUserFirstName(String userFirstName){
        this.userFirstName=userFirstName;
    }

    public String getUserLastName() {
        return userLastName;
    }
    public  void setUserLastName(String userLastName){
        this.userLastName= userLastName;
    }

    public String getItemName() {
        return itemName;
    }
    public void setItemName(String itemName){

        this.itemType= itemName;
    }

    public String getItemType() {
        return itemType;
    }
    public void setItemType(String itemType){
        this.itemType=itemType;
    }

    public int getItemQuantity() {
        return itemQuantity;
    }
    public void setItemQuantity(int itemQuantity){
        this.itemQuantity=itemQuantity;
    }

    public BigInteger getBarcode() {
        return itemBarcode;
    }
    public  void setBarcode(BigInteger ItemBarcode){
        this.itemBarcode=itemBarcode;
    }

    public Date getPaidDate() {
        return paidDate;
    }
    public void setPaidDate(Date paidDate){
        this.paidDate=paidDate;
    }

    public BigDecimal getTotalCost() {
        return totalCost;
    }
    public void setTotalCost(BigDecimal totalCost){
        this.totalCost=totalCost;
    }

    public BigDecimal getPaidCost() {
        return paidCost;
    }
    public void setPaidCost(BigDecimal paidCost){
        this.paidCost= paidCost;
    }

    public BigDecimal getRemainingCost() {
        return remainingCost;
    }
    public  void setRemainingCost(BigDecimal remainingCost){
        this.remainingCost= remainingCost;
    }

    public BigInteger getRemainingQuantity() {
        return remainingQuantity;
    }
    public void setRemainingQuantity(BigInteger remainingQuantity){
        this.remainingQuantity=remainingQuantity;
    }
}
