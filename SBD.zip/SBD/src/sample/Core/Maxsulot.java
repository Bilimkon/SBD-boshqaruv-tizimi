package sample.Core;
 import java.math.BigInteger;
 import java.math.BigDecimal;
 import java.sql.Date;
 /*
 Humoyun Qo'rg'onov  SBD(Software Business Development)
  */

public class Maxsulot {

   private  int id;
   private String itemName;
   private  String itemType;
   private  int itemQuantity;
   private BigDecimal  itemCost;
   private boolean itemStatus;
   private String itemDate;
   private String itemExpireDate;
   private String itemBarcode;
   private String itemTurlari;


   public  Maxsulot(String itemName, String itemType,int itemQuantity , BigDecimal itemCost , boolean itemStatus, String itemDate, String itemExpireDate,String itemBarcode,String itemTurlari){

       this(0,itemName,itemType,itemQuantity,itemCost,itemStatus,itemDate,itemExpireDate,itemBarcode,itemTurlari);



   }

   public Maxsulot(int id, String itemName, String itemType,int itemQuantity , BigDecimal itemCost , boolean itemStatus,String itemDate, String itemExpireDate,String itemBarcode,String itemTurlari){

       super();
       this.id=id;
       this.itemName= itemName;
       this.itemType= itemType;
       this.itemQuantity= itemQuantity;
       this.itemCost= itemCost;
       this.itemStatus= itemStatus;
       this.itemDate=itemDate;
       this.itemExpireDate= itemExpireDate;
       this.itemBarcode= itemBarcode;
       this.itemTurlari= itemTurlari;


   }

    public int getId() {
        return id;
    }
    public void setId(int id){
       this.id=id;
    }

    public String getItemName() {
        return itemName;
    }
    public void setItemName(String itemName){
       this.itemName=itemName;
    }

    public String getItemType() {
        return itemType;
    }
    public void setItemType(String itemType){
       this.itemType= itemType;
    }

    public int getItemQuantity() {
        return itemQuantity;
    }
    public void setItemQuantity(int itemQuantity){
       this.itemQuantity=itemQuantity;
    }

    public BigDecimal getItemCost() {
        return itemCost;
    }
    public void setItemCost(BigDecimal itemCost){
       this.itemCost= itemCost;
    }

    public boolean isItemStatus() {
        return itemStatus;
    }
    public void setItemStatus(boolean itemStatus){
       this.itemStatus= itemStatus;
    }

    public String getItemDate() {
        return itemDate;
    }
    public void setItemDate(String itemDate){
       this.itemDate= itemDate;
    }

    public String getItemExpireDate() {
        return itemExpireDate;
    }
    public  void setItemExpireDate(String itemExpireDate){
       this.itemExpireDate= itemExpireDate;
    }

    public String getItemBarcode() {
        return itemBarcode;
    }
    public void setItemBarcode(String itemBarcode){
       this.itemBarcode =itemBarcode;
    }

    public String getItemTurlari() {
        return itemTurlari;
    }
    public void setItemTurlari(String itemTurlari){
       this.itemTurlari=itemTurlari;
    }
    @Override
    public String toString(){
       return  String
               .format("Maxsulot [id=%s,itemName=%s, itemType=%s,itemQuantity=%s, itemCost=%s,itemStatus=%s, itemDate=%s,ItemExpireDate=%s,itemBarcode=%s,itemTurlari=%s]",
                id, itemName, itemType,itemQuantity,itemCost,itemStatus,itemDate,itemExpireDate,itemBarcode,itemTurlari);
    }



}
