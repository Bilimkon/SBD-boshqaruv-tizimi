package sample.Core;

import javax.swing.*;
import javax.xml.crypto.Data;
import  java.math.BigDecimal;
import java.math.BigInteger;
import java.util.Date;


/*
       Humoyun Qo'rg'onov  SBD  ( Software Business Development)
 */
public class User {

    private  int id;
    private String firstName;
    private String lastName;
    private String telNumber;
    private ImageIcon imageIcon;
    private BigDecimal salary;
    private Date date;
    private  String status;
    private  boolean admin;
    private String password;


    public User(String firstName, String lastName , String telNumber,ImageIcon imageIcon, BigDecimal salary , Date date,String status,boolean admin, String password){
        super();
        this.firstName=firstName;
        this.lastName= lastName;
        this.telNumber=telNumber;
        this.imageIcon = imageIcon;
        this.salary= salary;
        this.date= date;
        this.status= status;
        this.admin= admin;
        this.password= password;

    }


    public User(int id , String firstName, String lastName , String telNumber, ImageIcon imageIcon, BigDecimal salary , Date date, String status, boolean admin){
        super();
        this.id= id;
        this.firstName=firstName;
        this.lastName= lastName;
        this.telNumber=telNumber;
        this.imageIcon = imageIcon;
        this.salary= salary;
        this.date= date;
        this.status= status;
        this.admin= admin;
    }
    public  int getId(){
        return id;
    }public  void setId(int id){
        this.id=id;
    }

    public String getFirstName() {
        return firstName;
    }
    public void setFirstName(String firstName){
        this.firstName= firstName;
    }

    public String getLastName() {
        return lastName;
    }
    public void setLastName(String lastName){
        this.lastName= lastName;
    }

    public String getTelNumber() {
        return telNumber;
    }
    public void setTelNumber(String telNumber){
        this.telNumber= telNumber;
    }

    public ImageIcon getImageIcon() {
        return imageIcon;
    }
    public void setImageIcon(ImageIcon imageIcon){
        this.imageIcon= imageIcon;
    }

    public BigDecimal getSalary() {
        return salary;
    }
    public  void setSalary(BigDecimal salary){

        this.salary= salary;
    }

    public Date getDate() {
        return date;
    }
    public void setDate(Date date){
        this.date = date;
    }

    public String getStatus() {
        return status;
    }
    public void setStatus(String status){
        this.status= status;
    }

    public boolean isAdmin() {
        return admin;
    }
    public void setAdmin(boolean admin){
        this.admin= admin;
    }

    public String getPassword() {
        return password;
    }
    public void setPassword(String password){
        this.password= password;
    }
    @Override
    public  String toString(){
        return firstName+"  "+lastName;
    }
}
