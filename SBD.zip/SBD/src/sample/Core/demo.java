package sample.Core;

public class demo {
    private  String  name;
    private  int  age ;
    private  String university;
    private String  girlFriend;

    public  demo(String name, int  age , String university, String girlFriend){
        this.name=name;
        this.age=age;
        this.university=university;
        this.girlFriend=girlFriend;

    }
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public void setUniversity(String university) {
        this.university = university;
    }

    public void setGirlFriend(String girlFriend) {
        this.girlFriend = girlFriend;
    }

    public int getAge() {
        return age;
    }

    public String getUniversity() {
        return university;
    }

    public String getGirlFriend() {
        return girlFriend;
    }




}
