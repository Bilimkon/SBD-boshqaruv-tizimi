package sample.DAO;
import  java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.math.*;

import sample.Admin;
import sample.Controller;
import sample.DAO.*;
import sample.Core.*;
import sample.Core.Maxsulot;

import javax.swing.border.EmptyBorder;


public class MaxsulotDao {

    private  Connection myConn;

    public MaxsulotDao() throws  Exception{

        String  url1 = "jdbc:mysql://localhost:3306/sbd";
        String  name = "Humoyun";
        String  password="Bilimkon";

        // connect to database
        myConn = DriverManager.getConnection(url1, name, password);

        System.out.println("Employee DAO - DB connection successful to: "+url1);

    }
    public void AddMaxsulot() throws Exception{
        PreparedStatement myStmt= null;
        BigDecimal apple12 = new BigDecimal(10);
        try{
            //Prepare Statement
            myStmt=myConn.prepareStatement("INSERT INTO maxsulotlar"
                    +"(item_name,item_type,item_quantity,item_cost,item_status,item_date,item_expire_date,item_barcode,item_turlari)"
            +"VALUES (?,?,?,?,?,?,?,?,?)",Statement.RETURN_GENERATED_KEYS);

            int a1=9;
            String a2="Ano";
            String a3="Mev";
            int a4 = 7;


            /////////////////////////////////////////////////////////////////////


            myStmt.setString(1,"Somsa");
            myStmt.setString(2,a2 );
            myStmt.setInt(3,a1);
            myStmt.setBigDecimal(4,apple12);

            myStmt.setBoolean(5,true);
            myStmt.setString(6,a2);
            myStmt.setString(7,a2);
            myStmt.setString(8,a2);
            myStmt.setString(9,a2);

            myStmt.executeUpdate();

            System.out.print("Bajarildi");

        }
        finally {
            DaoUtils.close(myStmt);
        }

    }

    public List<Maxsulot>  getAllMaxsulot()throws  Exception{

        List<Maxsulot> list = new ArrayList<Maxsulot>();
        Statement myStmt=null;
        ResultSet myRs=null;

        try {
            myStmt = myConn.createStatement();
            myRs = myStmt.executeQuery("select * from maxsulotlar order by item_name");

            while (myRs.next()) {
                Maxsulot tempEmployee = convertRowToEmployee(myRs);
                list.add(tempEmployee);
            }

        }
        finally {
            DaoUtils.close(myStmt,myRs);
        }


        return list;
    }
    public List<Maxsulot> searchMaxsulot(String itemName) throws Exception {
        List<Maxsulot> list = new ArrayList<Maxsulot>();

        PreparedStatement myStmt = null;
        ResultSet myRs = null;

        try {
            itemName += "%";
            myStmt = myConn.prepareStatement("select * from maxsulotlar where item_name like ?  order by item_name");

            myStmt.setString(1, itemName);

            myRs = myStmt.executeQuery();

            while (myRs.next()) {
                Maxsulot tempEmployee = convertRowToEmployee(myRs);
                list.add(tempEmployee);
            }

            return list;
        }
        finally {
            DaoUtils.close(myStmt, myRs);
        }
    }

    public Maxsulot convertRowToEmployee(ResultSet myRs) throws SQLException {

        int id = myRs.getInt("id");
        String itemName = myRs.getString("item_name");
        String itemType = myRs.getString("item_type");
        int itemQuantity = myRs.getInt("item_quantity");
        BigDecimal itemCost = myRs.getBigDecimal("item_cost");
        Boolean itemStatus= myRs.getBoolean("item_status");
        String  itemDate = myRs.getString("item_date");
        String itemExpireDate =myRs.getString("item_expire_date");
        String itemBarcode = myRs.getString("item_barcode");
        String itemTurlari = myRs.getString("item_turlari");

        Maxsulot tempEmployee = new Maxsulot(id, itemName, itemType, itemQuantity, itemCost,itemStatus,itemDate,itemExpireDate,itemBarcode,itemTurlari);

        return tempEmployee;
    }





    public  static  void  main(String[] args)throws Exception{

    MaxsulotDao apple = new MaxsulotDao();
    System.out.print("Get all Maxsulot");
   System.out.print(apple.getAllMaxsulot());
   System.out.print("\nSearch Maxsulot");
   System.out.print(apple.searchMaxsulot("apple"));



    }
}
