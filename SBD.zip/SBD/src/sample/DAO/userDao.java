package sample.DAO;

public class userDao {
}
