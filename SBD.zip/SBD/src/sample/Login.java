package sample;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.io.IOException;


public class Login {

    public   Button btnKirish;
    public  TextField  textIsm;
    public TextField textPassword;



    public void btnActionKirish(){
        String  ismText = textIsm.getText();
        String  passText = textPassword.getText();
        String ism = "Humoyun";
        String password = "Bilimkon";

        if (ismText.equals(ism)&& passText.equals(password)) {
            Parent root;
            try {
                root = FXMLLoader.load(getClass().getResource("sample.fxml"));
                Stage stage = new Stage();
                stage.setTitle("SBD boshqaruv tizimi");
                stage.setScene(new Scene(root, 1080, 720));
                stage.show();
                // Hide this current window (if this is what you want)
                ((Node) (this.btnKirish)).getScene().getWindow().hide();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }else {
            JOptionPane.showMessageDialog(null ,"Ism yoki Parol notogri","Xatolik",JOptionPane.ERROR_MESSAGE );

        }










    }




}
