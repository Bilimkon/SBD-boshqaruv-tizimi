package sample.MaxsulotTableView;

import java.math.BigDecimal;
import java.util.Date;

public class MaxsulotTable {
    private String itemName;
    private String itemType;


    public MaxsulotTable(String nasiba, String apple) {
        this.itemName = "";
        this.itemType = "";


    }

    public MaxsulotTable(String itemName, String itemType, BigDecimal itemCost, int itemQuantity, Date itemExpireDate, String barcode) {
        this.itemName = itemName;
        this.itemType = itemType;

    }

    public String getItemType() {
        return itemType;
    }

    public void setItemType(String itemType) {
        this.itemType = itemType;
    }

    public void setItemName(String itemName) {
        this.itemName = itemName;
    }


    public String getItemName() {
        return itemName;
    }
}


