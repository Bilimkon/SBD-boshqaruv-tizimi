package sample;

import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.scene.control.Button;
import java.io.IOException;

public class Statistika  {

    public  Button btnStatistikaYuborish;

    public  void menuAsosiyOynaAction(){
        Parent root;
        try {
            root = FXMLLoader.load(getClass().getResource("sample.fxml"));
            Stage stage = new Stage();
            stage.setTitle("SBD boshqaruv tizimi");
            stage.setScene(new Scene(root, 1080, 720));
            stage.show();
            // Hide this current window (if this is what you want)
            ((Node) (this.btnStatistikaYuborish)).getScene().getWindow().hide();
        } catch (IOException e) {
            e.printStackTrace();
        }


    }
    public void menuAdminAction(){

        Parent root;
        try {
            root = FXMLLoader.load(getClass().getResource("Admin.fxml"));
            Stage stage = new Stage();
            stage.setTitle("SBD boshqaruv tizimi");
            stage.setScene(new Scene(root, 1080, 720));
            stage.show();
            // Hide this current window (if this is what you want)
            ((Node) (this.btnStatistikaYuborish)).getScene().getWindow().hide();
        } catch (IOException e) {
            e.printStackTrace();
        }

    }



}
